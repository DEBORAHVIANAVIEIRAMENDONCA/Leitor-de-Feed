/* feedreader.js
  * TODO: Este é o arquivo de especificações que o Jasmine irá ler e conter
  * todos os testes que serão executados no seu aplicativo.
/ * Estamos colocando todos os nossos testes dentro da função $ ()
  * já que alguns desses testes podem requerer elementos DOM. Nós queremos
  * para garantir que eles não sejam executados até que o DOM esteja pronto.
  */
$(function () {
    /*TODO: Esta é a nossa primeira suíte de testes - uma suíte de testes contém apenas
     * um conjunto relacionado de testes. Esta suite é toda sobre o RSS
     * alimenta definições, a variável allFeeds em nossa aplicação.
     */
    describe('RSS Feeds', function () {
        /*TODO: Este é o nosso primeiro teste - ele testa para garantir que o
          * allFeeds variável foi definida e que não é vazio Experimente isso antes de começar
          * o resto deste projeto. O que acontece quando você muda
          * allFeeds em app.js para ser uma matriz vazia e atualizar o
          * página*/
        it('are defined', function () {
            expect(allFeeds).toBeDefined();
            expect(allFeeds.length).not.toBe(0);
        });

        /*TODO: escreve um teste que faz um loop em cada feed no objeto allFeeds e garante que ele tenha um URL definido e que o URL não está vazio.*/
        it('url nao esta vazio', function () {
            allFeeds.forEach(function (feed) {
                expect(feed.url).toBeDefined();
                expect(feed.url.length).not.toBe(0);
            })
        })
        /*TODO: escreve um teste que faz um loop em cada feed no objeto allFeeds e garante que ele tenha um nome definido e que o nome não está vazio. */
        it('name nao esta vazio', function () {
            allFeeds.forEach(function (feed) {
                expect(feed.name).toBeDefined();
                expect(feed.name.length).not.toBe(0);
            })
        })

    });

    /*TODO: Escreva um novo conjunto de testes chamado "O menu" ,Escreva um teste que garanta que o elemento de menu seja escondido por padrão. Você terá que analisar o HTML e o CSS para determinar como estamos executando o ocultação / exibição do elemento de menu.*/
    describe('Menu', function () {
        it('Menu escondido por padrão', function () {
            expect($('body').hasClass('menu-hidden')).toBe(true);
        })
        it('A visibilidade do menu é alternada conforme click', function () {
            $('.icon-list').click();
            expect($('body').hasClass('menu-hidden')).toBe(false);
            $('.icon-list').click();
            expect($('body').hasClass('menu-hidden')).toBe(true);
        })
    })

    /*TODO: escreve um novo conjunto de testes chamado "Entradas Iniciais" */
    /* Escreva um teste que garanta quando o loadFeed função é chamada e completa seu trabalho, há pelo menos um único elemento .entry dentro do contêiner .feed.
     Lembre-se, loadFeed () é assíncrono, então esse teste exigirá
     o uso da função beforeEach e assynchronous done () de Jasmine. */
    describe('Entradas iniciais', function () {
        beforeEach(function (done) {
            loadFeed(0, done); //função assincrona com o teste
        })
        it('Entradas iniciais estão presentes', function () {
            expect($('.feed .entry').length).toBeGreaterThan(0)
        })
    })
   

    /*TODO: escreve um novo conjunto de testes chamado "New Feed Selection" 
       Escreva um teste que garanta quando um novo feed é carregado
       pela função loadFeed que o conteúdo realmente muda.Lembre-se, loadFeed () é assíncrono.*/
    describe('Nova seleção de Feed', function () {
        var primeiroFeed;
        beforeEach(function (done) {
            loadFeed(0, function () {
                primeiroFeed = $('.feed').html()
                loadFeed(1, done);
            })
        })
        it('Feed diferente do outro', function () {
            expect($('.feed').html()).not.toBe(primeiroFeed);

        })

    })

});